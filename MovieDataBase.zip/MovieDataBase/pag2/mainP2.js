const app2 = Vue.createApp({
    data() {
        return {
        }
    },
    methods: {

    }

})