app2.component('movieDetails', {
    props: {
        id: Number,
    },

    template:
    /*html*/
    `
    `,

    method:{
    }
})